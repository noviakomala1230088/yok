package com.example.tugbes;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class voucher extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_voucher);
    }
}
